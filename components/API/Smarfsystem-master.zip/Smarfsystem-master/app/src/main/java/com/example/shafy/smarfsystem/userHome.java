package com.example.shafy.smarfsystem;

import android.net.Uri;
import android.os.AsyncTask;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.EventLog;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;

import com.example.shafy.smarfsystem.data;

import static com.example.shafy.smarfsystem.data.data;

public class userHome extends AppCompatActivity {

    private static final String USER_ID =
            "mina";
    private static final String USER_PASS =
            "mina123mina";;
    private static String COMMAND ="";
    private static String QUERY_TYPE ="";
    private static String DEVICE_ID ="";
    private static String REQUEST_URL =
            "http://smarf.meena-erian.com/?";
    public static final String LOG_TAG = userHome.class.getSimpleName();
    private String inputref="";
    private data data;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_home);
        final RelativeLayout over=(RelativeLayout)findViewById(R.id.over);
        final CheckBox satView =(CheckBox)findViewById(R.id.cb);
        satView.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

                                               @Override
                                               public void onCheckedChanged(CompoundButton buttonView,boolean isChecked) {
                                                    if(satView.isChecked()){
                                                        over.setVisibility(View.VISIBLE);
                                                    }
                                                   else over.setVisibility(View.GONE);
                                               }
                                           }
        );
        Query q= new Query();
        q.execute();
    }
    public void ref(View view){
        Query q= new Query();
        q.execute();
    }
    public void getdata(){}
    public void ChangeR(View view){
        DEVICE_ID="ic1";
        COMMAND="edit";
        QUERY_TYPE="referenceHumidity";
        EditText reference = (EditText) findViewById(R.id.ref);
        inputref=reference.getText().toString();
        Change ref= new Change();
        ref.execute();
    }
    public void ChangeWs(View view){
        DEVICE_ID="ic1";
        COMMAND="edit";
        QUERY_TYPE="irrigation";
        TextView status = (TextView) findViewById(R.id.ws);
        if(status.getText().equals("OFF"))
            inputref="ON";
        else
            inputref="OFF";
        Change ref= new Change();
        ref.execute();
    }
    private void updateUi(data data) {


        TextView perH = (TextView) findViewById(R.id.per);
        perH.setText(data.getPer());

        EditText reference = (EditText) findViewById(R.id.ref);
        reference.setHint(data.getRef());

        TextView status = (TextView) findViewById(R.id.ws);
        status.setText(data.getState());
    }


    private class Query extends AsyncTask <URL,Void,data>{
        protected data doInBackground (URL... urls){

            DEVICE_ID="ic1";
            COMMAND="query";
            QUERY_TYPE="referenceHumidity";
            URL url1 = createUrl(REQUEST_URL+"command="+COMMAND+"&userId="+USER_ID+"&userPassword="+USER_PASS+"&deviceId="+DEVICE_ID+"&query="+QUERY_TYPE);
            String jsonResponse1 = "";
            DEVICE_ID="ic1";
            COMMAND="query";
            QUERY_TYPE="irrigation";
            URL url2 = createUrl(REQUEST_URL+"command="+COMMAND+"&userId="+USER_ID+"&userPassword="+USER_PASS+"&deviceId="+DEVICE_ID+"&query="+QUERY_TYPE);
            String jsonResponse2 = "";
            DEVICE_ID="ss1";
            COMMAND="query";
            QUERY_TYPE="history.last(1)";
            URL url3 = createUrl(REQUEST_URL+"command="+COMMAND+"&userId="+USER_ID+"&userPassword="+USER_PASS+"&deviceId="+DEVICE_ID+"&query="+QUERY_TYPE);
            String jsonResponse3 = "";

            try {
                jsonResponse1 = makeHttpRequest(url1);
                jsonResponse2 = makeHttpRequest(url2);
                jsonResponse3 = makeHttpRequest(url3);
            } catch (IOException e) {
                // TODO Handle the IOException
            }

            data data= extractFeatureFromJson(jsonResponse1,jsonResponse2,jsonResponse3);
            return data;
        }

        @Override
        protected void onPostExecute(data data) {
            if (data == null) {
                return;
            }
            updateUi(data);
        }

        private URL createUrl(String stringUrl) {
            URL url = null;
            try {
                url = new URL(stringUrl);
            } catch (MalformedURLException exception) {
                Log.e(LOG_TAG, "Error with creating URL", exception);
                return null;
            }
            return url;
        }
        private String makeHttpRequest(URL url) throws IOException {
            String jsonResponse = "";
            HttpURLConnection urlConnection = null;
            InputStream inputStream = null;
            try {
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.setReadTimeout(10000 /* milliseconds */);
                urlConnection.setConnectTimeout(15000 /* milliseconds */);
                urlConnection.connect();
                inputStream = urlConnection.getInputStream();
                jsonResponse = readFromStream(inputStream);
            } catch (IOException e) {
                // TODO: Handle the exception
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
                if (inputStream != null) {
                    // function must handle java.io.IOException here
                    inputStream.close();
                }
            }
            return jsonResponse;
        }
        private String readFromStream(InputStream inputStream) throws IOException {
            StringBuilder output = new StringBuilder();
            if (inputStream != null) {
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream, Charset.forName("UTF-8"));
                BufferedReader reader = new BufferedReader(inputStreamReader);
                String line = reader.readLine();
                while (line != null) {
                    output.append(line);
                    line = reader.readLine();
                }
            }
            return output.toString();
        }
        private data extractFeatureFromJson(String JSON1,String JSON2,String JSON3) {
            try {
                String referenceHumidity="";
                String humidity ="";
                String irrigation ="";
                JSONObject baseJsonResponse1 = new JSONObject(JSON1);
                String str1=baseJsonResponse1.getString("responseType");
                if(str1.equals("Data")) {
                    referenceHumidity = baseJsonResponse1.getString("content");
                }
                JSONObject baseJsonResponse2 = new JSONObject(JSON2);
                String str2=baseJsonResponse2.getString("responseType");
                if(str2.equals("Data")) {
                    irrigation = baseJsonResponse2.getString("content");
                }
                JSONObject baseJsonResponse3 = new JSONObject(JSON3);
                String str3=baseJsonResponse3.getString("responseType");
                if(str3.equals("Data")) {
                        JSONArray content =baseJsonResponse3.getJSONArray("content");
                        JSONObject json =content.getJSONObject(0);
                    humidity = json.getString("humidity");
                }
                return new data(humidity, irrigation, referenceHumidity);
            } catch (JSONException e) {

            }
            return null;
        }
    }


    private class Change extends AsyncTask <URL,Void,data> {
        protected data doInBackground(URL... urls) {

            URL url = createUrl(REQUEST_URL+"command="+COMMAND+"&userId="+USER_ID+"&userPassword="+USER_PASS+"&deviceId="+DEVICE_ID+"&"+QUERY_TYPE+"="+inputref);
            String jsonResponse = "";
            try {
                jsonResponse = makeHttpRequest(url);
            } catch (IOException e) {
                // TODO Handle the IOException
            }

            extractFeatureFromJson(jsonResponse);
            return null;
        }

        @Override
        protected void onPostExecute(data data) {

            Query q= new Query();
            q.execute();
        }

        private URL createUrl(String stringUrl) {
            URL url = null;
            try {
                url = new URL(stringUrl);
            } catch (MalformedURLException exception) {
                Log.e(LOG_TAG, "Error with creating URL", exception);
                return null;
            }
            return url;
        }

        private String makeHttpRequest(URL url) throws IOException {
            String jsonResponse = "";
            HttpURLConnection urlConnection = null;
            InputStream inputStream = null;
            try {
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.setReadTimeout(10000 /* milliseconds */);
                urlConnection.setConnectTimeout(15000 /* milliseconds */);
                urlConnection.connect();
                inputStream = urlConnection.getInputStream();
                jsonResponse = readFromStream(inputStream);
            } catch (IOException e) {
                // TODO: Handle the exception
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
                if (inputStream != null) {
                    // function must handle java.io.IOException here
                    inputStream.close();
                }
            }
            return jsonResponse;
        }

        private String readFromStream(InputStream inputStream) throws IOException {
            StringBuilder output = new StringBuilder();
            if (inputStream != null) {
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream, Charset.forName("UTF-8"));
                BufferedReader reader = new BufferedReader(inputStreamReader);
                String line = reader.readLine();
                while (line != null) {
                    output.append(line);
                    line = reader.readLine();
                }
            }
            return output.toString();
        }

        private void extractFeatureFromJson(String JSON) {
            try {
                JSONObject baseJsonResponse = new JSONObject(JSON);
                String responseType = baseJsonResponse.getString("responseType");
                if(responseType=="Data"){
                String content = baseJsonResponse.getString("content");
                    if(content.equals("Data updated successfully")){}
                }
                // If there are results in the features array

                // Create a new {@link Event} object


            } catch (JSONException e) {

            }
            }
    }
}
