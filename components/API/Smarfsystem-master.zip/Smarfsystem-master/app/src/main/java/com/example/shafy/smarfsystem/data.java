package com.example.shafy.smarfsystem;

/**
 * Created by shafy on 04/02/2017.
 */
import java.util.ArrayList;
import java.util.List;
import java.util.logging.StreamHandler;

public class data {
    private String per;
    private String state;
    private String ref;
    public static data data;
    public data (String per, String state , String ref){
        this.per=per;
        this.state=state;
        this.ref=ref;
    }
    public String getPer(){
        return per;
    }
    public String getState(){
    return state;
    }
    public String getRef(){
return  ref;
    }
    public void setPer(String p){
        per=p;
    }
    public void setState(String s){
        state=s;
    }
    public void setRef(String r){
        ref=r;
    }
    public String getsource(){
        String source = "http://smarf.meena-erian.com";
        return source;
    }

}
